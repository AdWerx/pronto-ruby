require  'pronto'

class My_Class
    def myMethod()
        puts 'hello'
        end
end
